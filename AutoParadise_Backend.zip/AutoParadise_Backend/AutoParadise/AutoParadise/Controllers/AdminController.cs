﻿using AutoParadise.Repos;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace AutoParadise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private IAdminRepo _adminRepo;

        public AdminController(IAdminRepo adminRepo)
        {
            _adminRepo = adminRepo;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBy(Guid id)
        {
            Admin? entity = new();
            if (_adminRepo is not null)
            {
                entity = await _adminRepo.GetBy(id);
                if (entity != null)
                    return Ok(entity);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }

        [HttpGet]
        public async Task<IActionResult> SelectAllRecordToListAsync()
        {
            List<Admin>? users = new();

            if (_adminRepo != null)
            {
                users = await _adminRepo.GetAll();
                return Ok(users);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }
        [HttpPut()]
        public async Task<ActionResult> UpdateAdminAsync(AdminDto entity)
        {
            ControllerResponse response = new();
            if (_adminRepo is not null)
            {
                // response = await _adminRepo.UpdateAdminAsync(AdminAssambler.ToModel( entity));
                response = await _adminRepo.UpdateAdminAsync(entity.ToModel());
                if (response.HasError)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            response.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return BadRequest(response);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdminAsync(Guid id)
        {
            ControllerResponse response = new();
            if (_adminRepo is not null)
            {
                response = await _adminRepo.DeleteAsync(id);
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    Console.WriteLine(response.Error);
                    response.ClearAndAddError("A diák adatainak törlése nem sikerült!");
                    return BadRequest(response);

                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> InsertAdminAsync(AdminDto adminDto)
        {
            ControllerResponse response = new();
            if (_adminRepo is not null)
            {
                response = await _adminRepo.InsertAdminAsync(adminDto.ToModel());
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    return BadRequest(response);
                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }
    }
}
