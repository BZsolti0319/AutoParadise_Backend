﻿using AutoParadise.Repos;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace AutoParadise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CarPartsController : ControllerBase
    {
        private ICarPartsRepo _carPartsRepo;

        public CarPartsController(ICarPartsRepo carPartsRepo)
        {
            _carPartsRepo = carPartsRepo;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBy(Guid id)
        {
            CarParts? entity = new();
            if (_carPartsRepo is not null)
            {
                entity = await _carPartsRepo.GetBy(id);
                if (entity != null)
                    return Ok(entity);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }

        [HttpGet]
        public async Task<IActionResult> SelectAllRecordToListAsync()
        {
            List<CarParts>? users = new();

            if (_carPartsRepo != null)
            {
                users = await _carPartsRepo.GetAll();
                return Ok(users);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }
        [HttpPut()]
        public async Task<ActionResult> UpdateCarPartsAsync(CarPartsDto entity)
        {
            ControllerResponse response = new();
            if (_carPartsRepo is not null)
            {
                // response = await _carPartsRepo.UpdateCarPartsAsync(CarPartsAssambler.ToModel( entity));
                response = await _carPartsRepo.UpdateCarPartsAsync(entity.ToModel());
                if (response.HasError)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            response.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return BadRequest(response);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCarPartsAsync(Guid id)
        {
            ControllerResponse response = new();
            if (_carPartsRepo is not null)
            {
                response = await _carPartsRepo.DeleteAsync(id);
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    Console.WriteLine(response.Error);
                    response.ClearAndAddError("A diák adatainak törlése nem sikerült!");
                    return BadRequest(response);

                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> InsertCarPartsAsync(CarPartsDto carPartsDto)
        {
            ControllerResponse response = new();
            if (_carPartsRepo is not null)
            {
                response = await _carPartsRepo.InsertCarPartsAsync(carPartsDto.ToModel());
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    return BadRequest(response);
                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }
    }
}
