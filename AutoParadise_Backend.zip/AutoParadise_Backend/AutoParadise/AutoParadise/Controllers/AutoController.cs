﻿using AutoParadise.Repos;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace AutoParadise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AutoController : ControllerBase
    {
        private IAutoRepo _autoRepo;

        public AutoController(IAutoRepo autoRepo)
        {
            _autoRepo = autoRepo;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBy(Guid id)
        {
            Auto? entity = new();
            if (_autoRepo is not null)
            {
                entity = await _autoRepo.GetBy(id);
                if (entity != null)
                    return Ok(entity);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }

        [HttpGet]
        public async Task<IActionResult> SelectAllRecordToListAsync()
        {
            List<Auto>? autos = new();

            if (_autoRepo != null)
            {
                autos = await _autoRepo.GetAll();
                return Ok(autos);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }
        [HttpPut()]
        public async Task<ActionResult> UpdateAutoAsync(AutoDto entity)
        {
            ControllerResponse response = new();
            if (_autoRepo is not null)
            {
                // response = await _autoRepo.UpdateAutoAsync(AutoAssambler.ToModel( entity));
                response = await _autoRepo.UpdateAutoAsync(entity.ToModel());
                if (response.HasError)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            response.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return BadRequest(response);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAutoAsync(Guid id)
        {
            ControllerResponse response = new();
            if (_autoRepo is not null)
            {
                response = await _autoRepo.DeleteAsync(id);
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    Console.WriteLine(response.Error);
                    response.ClearAndAddError("A diák adatainak törlése nem sikerült!");
                    return BadRequest(response);

                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> InsertAutoAsync(AutoDto autoDto)
        {
            ControllerResponse response = new();
            if (_autoRepo is not null)
            {
                response = await _autoRepo.InsertAutoAsync(autoDto.ToModel());
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    return BadRequest(response);
                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }
    }
}
