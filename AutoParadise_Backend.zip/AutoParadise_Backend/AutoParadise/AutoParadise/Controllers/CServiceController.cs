﻿using AutoParadise.Repos;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace AutoParadise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CServiceController : ControllerBase
    {
        private ICServiceRepo _cServiceRepo;

        public CServiceController(ICServiceRepo cServiceRepo)
        {
            _cServiceRepo = cServiceRepo;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBy(Guid id)
        {
            CService? entity = new();
            if (_cServiceRepo is not null)
            {
                entity = await _cServiceRepo.GetBy(id);
                if (entity != null)
                    return Ok(entity);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }

        [HttpGet]
        public async Task<IActionResult> SelectAllRecordToListAsync()
        {
            List<CService>? cServices = new();

            if (_cServiceRepo != null)
            {
                cServices = await _cServiceRepo.GetAll();
                return Ok(cServices);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }
        [HttpPut()]
        public async Task<ActionResult> UpdateCServiceAsync(CServiceDto entity)
        {
            ControllerResponse response = new();
            if (_cServiceRepo is not null)
            {
                // response = await _adminRepo.UpdateAdminAsync(AdminAssambler.ToModel( entity));
                response = await _cServiceRepo.UpdateCServiceAsync(entity.ToModel());
                if (response.HasError)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            response.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return BadRequest(response);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            ControllerResponse response = new();
            if (_cServiceRepo is not null)
            {
                response = await _cServiceRepo.DeleteAsync(id);
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    Console.WriteLine(response.Error);
                    response.ClearAndAddError("Az ügyfélszolgálatos adatainak törlése nem sikerült!");
                    return BadRequest(response);

                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> InsertCServiceAsync(CServiceDto cServiceDto)
        {
            ControllerResponse response = new();
            if (_cServiceRepo is not null)
            {
                response = await _cServiceRepo.InsertCServiceAsync(cServiceDto.ToModel());
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    return BadRequest(response);
                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }
    }
}
