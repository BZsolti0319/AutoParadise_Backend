﻿using AutoParadise.Repos;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace AutoParadise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private IUserRepo _userRepo;

        public UserController(IUserRepo userRepo)
        {
            _userRepo = userRepo;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBy(Guid id)
        {
            User? entity = new();
            if (_userRepo is not null)
            {
                entity = await _userRepo.GetBy(id);
                if (entity != null)
                    return Ok(entity);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }

        [HttpGet]
        public async Task<IActionResult> SelectAllRecordToListAsync()
        {
            List<User>? users = new();

            if (_userRepo != null)
            {
                users = await _userRepo.GetAll();
                return Ok(users);
            }
            return BadRequest("Az adatok elérhetetlenek!");
        }
        [HttpPut()]
        public async Task<ActionResult> UpdateUserAsync(UserDto entity)
        {
            ControllerResponse response = new();
            if (_userRepo is not null)
            {
                // response = await _autoRepo.UpdateAutoAsync(AutoAssambler.ToModel( entity));
                response = await _userRepo.UpdateUserAsync(entity.ToModel());
                if (response.HasError)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            response.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return BadRequest(response);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserAsync(Guid id)
        {
            ControllerResponse response = new();
            if (_userRepo is not null)
            {
                response = await _userRepo.DeleteAsync(id);
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    Console.WriteLine(response.Error);
                    response.ClearAndAddError("A diák adatainak törlése nem sikerült!");
                    return BadRequest(response);

                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> InsertUserAsync(UserDto userDto)
        {
            ControllerResponse response = new();
            if (_userRepo is not null)
            {
                response = await _userRepo.InsertUserAsync(userDto.ToModel());
                if (!response.HasError)
                {
                    return Ok(response);
                }
                else
                {
                    return BadRequest(response);
                }
            }
            response.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return BadRequest(response);
        }
    }
}
