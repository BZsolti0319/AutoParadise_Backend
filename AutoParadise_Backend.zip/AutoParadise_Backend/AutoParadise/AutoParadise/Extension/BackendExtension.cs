﻿using AutoParadise.Context;
using AutoParadise.Repos;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace AutoParadise.Extension
{
    public static class BackendExtension
    {
        public static void AddBackend(this IServiceCollection services)
        {
            services.ConfigureCors();
            services.ConfigureInMemoryContext();
            services.ConfigureRepos();
        }

        private static void ConfigureCors(this IServiceCollection services)
        {
            services.AddCors(option =>
                 option.AddPolicy(name: "AutoParadiseCors",
                     policy =>
                     {
                         policy.WithOrigins("https://0.0.0.0:7020/")
                         .AllowAnyHeader()
                         .AllowAnyMethod();
                     }
                 )
            );
        }
        private static void ConfigureInMemoryContext(this IServiceCollection services)
        {
            string dbNameInMemoryContext = "AutoParadise" + Guid.NewGuid();
            services.AddDbContext<AutoParadiseInMemoryContext>
            (
                 options => options.UseInMemoryDatabase(databaseName: dbNameInMemoryContext),
                 ServiceLifetime.Scoped,
                 ServiceLifetime.Scoped
            );
        }
        public static void ConfigureRepos(this IServiceCollection services)
        {
            services.AddScoped<IUserRepo, UserRepo>();
            services.AddScoped<IAdminRepo, AdminRepo>();
            services.AddScoped<IAutoRepo, AutoRepo>();
            services.AddScoped<ICarPartsRepo, CarPartsRepo>();
            services.AddScoped<ICServiceRepo, CServiceRepo>();
        }
    }
}
