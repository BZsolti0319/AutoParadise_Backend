﻿using AutoParadise.Context;
using System.Runtime.CompilerServices;

namespace AutoParadise.Extension
{
    public static class WebApplicationExtension
    {
        public static void ConfigureWebApplication(this WebApplication webApplication)
        {
            webApplication.ConfigureWebAppCors();
            webApplication.ConfigureInMemoryTestData();
        }

        private static void ConfigureWebAppCors(this WebApplication app)
        {
            app.UseCors("AutoParadiseCors");
        }

        private static void ConfigureInMemoryTestData(this WebApplication app)
        {
            using (var scope = app.Services.CreateAsyncScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<AutoParadiseInMemoryContext>();
                // InMemory test data
                dbContext.Database.EnsureCreated();
            }
        }
    }
}
