﻿using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;

namespace AutoParadise.Repos
{
    public interface IUserRepo
    {
        Task<List<User>> GetAll();
        Task<User?> GetBy(Guid id);
        Task<ControllerResponse> UpdateUserAsync(User user);
        Task<ControllerResponse> DeleteAsync(Guid id);
        Task<ControllerResponse> InsertUserAsync(User user);
    }
}
