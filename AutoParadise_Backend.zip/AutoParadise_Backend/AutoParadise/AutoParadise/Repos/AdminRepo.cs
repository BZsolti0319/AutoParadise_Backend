﻿using AutoParadise.Context;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Repos
{
    public class AdminRepo : IAdminRepo
    {
        private readonly AutoParadiseInMemoryContext _dbContext;

        public AdminRepo(AutoParadiseInMemoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Admin?> GetBy(Guid id)
        {
            return await _dbContext.Admins.FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<Admin>> GetAll()
        {
            return await _dbContext.Admins.ToListAsync();
        }
        public async Task<ControllerResponse> UpdateAdminAsync(Admin admin)
        {
            ControllerResponse response = new ControllerResponse();
            _dbContext.ChangeTracker.Clear();
            _dbContext.Entry(admin).State = EntityState.Modified;
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(AdminRepo)} osztály, {nameof(UpdateAdminAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{admin} frissítése nem sikerült");
            }
            return response;
        }
        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse response = new ControllerResponse();
            Admin? adminToDelete = await GetBy(id);
            if (adminToDelete == null || adminToDelete == default)
            {
                response.AppendNewError($"{id} idével rendelkező diák nem található!");
                response.AppendNewError("A diák törlése nem sikerült!");
            }
            else
            {
                _dbContext.ChangeTracker.Clear();
                _dbContext.Entry(adminToDelete).State = EntityState.Deleted;
                await _dbContext.SaveChangesAsync();
            }
            return response;

        }

        private async Task<ControllerResponse> InsertNewItemAsync(Admin admin)
        {
            ControllerResponse response = new ControllerResponse();
            try
            {
                _dbContext.Admins.Add(admin);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(AdminRepo)} osztály, {nameof(InsertNewItemAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{admin} osztály hozzáadása az adatbázishoz nem sikerült!");
            }
            return response;
        }

        public async Task<ControllerResponse> InsertAdminAsync(Admin admin)
        {
            if (admin.HasId)
            {
                return await UpdateAdminAsync(admin);
            }
            else
            {
                return await InsertNewItemAsync(admin);
            }
        }
    }
}
