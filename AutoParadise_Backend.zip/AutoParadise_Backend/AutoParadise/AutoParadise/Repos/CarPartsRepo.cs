﻿using AutoParadise.Context;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Repos
{
    public class CarPartsRepo : ICarPartsRepo
    {
        private readonly AutoParadiseInMemoryContext _dbContext;

        public CarPartsRepo(AutoParadiseInMemoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<CarParts?> GetBy(Guid id)
        {
            return await _dbContext.CarParts.FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<CarParts>> GetAll()
        {
            return await _dbContext.CarParts.ToListAsync();
        }
        public async Task<ControllerResponse> UpdateCarPartsAsync(CarParts carParts)
        {
            ControllerResponse response = new ControllerResponse();
            _dbContext.ChangeTracker.Clear();
            _dbContext.Entry(carParts).State = EntityState.Modified;
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(CarPartsRepo)} osztály, {nameof(UpdateCarPartsAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{carParts} frissítése nem sikerült");
            }
            return response;
        }
        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse response = new ControllerResponse();
            CarParts? carPartsToDelete = await GetBy(id);
            if (carPartsToDelete == null || carPartsToDelete == default)
            {
                response.AppendNewError($"{id} idével rendelkező diák nem található!");
                response.AppendNewError("A diák törlése nem sikerült!");
            }
            else
            {
                _dbContext.ChangeTracker.Clear();
                _dbContext.Entry(carPartsToDelete).State = EntityState.Deleted;
                await _dbContext.SaveChangesAsync();
            }
            return response;

        }

        private async Task<ControllerResponse> InsertNewItemAsync(CarParts carParts)
        {
            ControllerResponse response = new ControllerResponse();
            try
            {
                _dbContext.CarParts.Add(carParts);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(CarPartsRepo)} osztály, {nameof(InsertNewItemAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{carParts} osztály hozzáadása az adatbázishoz nem sikerült!");
            }
            return response;
        }

        public async Task<ControllerResponse> InsertCarPartsAsync(CarParts carParts)
        {
            if (carParts.HasId)
            {
                return await UpdateCarPartsAsync(carParts);
            }
            else
            {
                return await InsertNewItemAsync(carParts);
            }
        }
    }
}
