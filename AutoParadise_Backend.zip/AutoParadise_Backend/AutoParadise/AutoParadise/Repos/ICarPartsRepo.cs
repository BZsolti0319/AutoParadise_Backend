﻿using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;

namespace AutoParadise.Repos
{
    public interface ICarPartsRepo
    {
        Task<List<CarParts>> GetAll();
        Task<CarParts?> GetBy(Guid id);
        Task<ControllerResponse> UpdateCarPartsAsync(CarParts carParts);
        Task<ControllerResponse> DeleteAsync(Guid id);
        Task<ControllerResponse> InsertCarPartsAsync(CarParts carParts);
    }
}
