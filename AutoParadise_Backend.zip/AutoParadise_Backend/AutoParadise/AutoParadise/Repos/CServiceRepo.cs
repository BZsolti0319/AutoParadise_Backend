﻿using AutoParadise.Context;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Repos
{
    public class CServiceRepo : ICServiceRepo
    {
        private readonly AutoParadiseInMemoryContext _dbContext;

        public CServiceRepo(AutoParadiseInMemoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<CService?> GetBy(Guid id)
        {
            return await _dbContext.CService.FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<CService>> GetAll()
        {
            return await _dbContext.CService.ToListAsync();
        }
        public async Task<ControllerResponse> UpdateCServiceAsync(CService cService)
        {
            ControllerResponse response = new ControllerResponse();
            _dbContext.ChangeTracker.Clear();
            _dbContext.Entry(cService).State = EntityState.Modified;
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(CServiceRepo)} osztály, {nameof(UpdateCServiceAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{cService} frissítése nem sikerült");
            }
            return response;
        }
        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse response = new ControllerResponse();
            CService? cServiceToDelete = await GetBy(id);
            if (cServiceToDelete == null || cServiceToDelete == default)
            {
                response.AppendNewError($"{id} idével rendelkező diák nem található!");
                response.AppendNewError("A diák törlése nem sikerült!");
            }
            else
            {
                _dbContext.ChangeTracker.Clear();
                _dbContext.Entry(cServiceToDelete).State = EntityState.Deleted;
                await _dbContext.SaveChangesAsync();
            }
            return response;

        }

        private async Task<ControllerResponse> InsertNewItemAsync(CService cService)
        {
            ControllerResponse response = new ControllerResponse();
            try
            {
                _dbContext.CService.Add(cService);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(CServiceRepo)} osztály, {nameof(InsertNewItemAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{cService} osztály hozzáadása az adatbázishoz nem sikerült!");
            }
            return response;
        }

        public async Task<ControllerResponse> InsertCServiceAsync(CService cService)
        {
            if (cService.HasId)
            {
                return await UpdateCServiceAsync(cService);
            }
            else
            {
                return await InsertNewItemAsync(cService);
            }
        }
    }
}
