﻿using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;

namespace AutoParadise.Repos
{
    public interface ICServiceRepo
    {
        Task<List<CService>> GetAll();
        Task<CService?> GetBy(Guid id);
        Task<ControllerResponse> UpdateCServiceAsync(CService cService);
        Task<ControllerResponse> DeleteAsync(Guid id);
        Task<ControllerResponse> InsertCServiceAsync(CService cService);
    }
}
