﻿using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;

namespace AutoParadise.Repos
{
    public interface IAdminRepo
    {
        Task<List<Admin>> GetAll();
        Task<Admin?> GetBy(Guid id);
        Task<ControllerResponse> UpdateAdminAsync(Admin admin);
        Task<ControllerResponse> DeleteAsync(Guid id);
        Task<ControllerResponse> InsertAdminAsync(Admin admin);
    }
}
