﻿using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;

namespace AutoParadise.Repos
{
    public interface IAutoRepo
    {
        Task<List<Auto>> GetAll();
        Task<Auto?> GetBy(Guid id);
        Task<ControllerResponse> UpdateAutoAsync(Auto auto);
        Task<ControllerResponse> DeleteAsync(Guid id);
        Task<ControllerResponse> InsertAutoAsync(Auto auto);
    }
}
