﻿using AutoParadise.Context;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using AutoParadise.Shared.Assemblers;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Repos
{
    public class UserRepo : IUserRepo
    {
        private readonly AutoParadiseInMemoryContext _dbContext;

        public UserRepo(AutoParadiseInMemoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<User?> GetBy(Guid id)
        {
            return await _dbContext.Users.FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<User>> GetAll()
        {
            return await _dbContext.Users.ToListAsync();
        }
        public async Task<ControllerResponse> UpdateUserAsync(User user)
        {
            ControllerResponse response = new ControllerResponse();
            _dbContext.ChangeTracker.Clear();
            _dbContext.Entry(user).State = EntityState.Modified;
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(UserRepo)} osztály, {nameof(UpdateUserAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{user} frissítése nem sikerült");
            }
            return response;
        }
        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse response = new ControllerResponse();
            User? userToDelete = await GetBy(id);
            if (userToDelete == null || userToDelete == default)
            {
                response.AppendNewError($"{id} idével rendelkező diák nem található!");
                response.AppendNewError("A diák törlése nem sikerült!");
            }
            else
            {
                _dbContext.ChangeTracker.Clear();
                _dbContext.Entry(userToDelete).State = EntityState.Deleted;
                await _dbContext.SaveChangesAsync();
            }
            return response;

        }

        private async Task<ControllerResponse> InsertNewItemAsync(User user)
        {
            ControllerResponse response = new ControllerResponse();
            try
            {
                _dbContext.Users.Add(user);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(UserRepo)} osztály, {nameof(InsertNewItemAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{user} osztály hozzáadása az adatbázishoz nem sikerült!");
            }
            return response;
        }

        public async Task<ControllerResponse> InsertUserAsync(User user)
        {
            if (user.HasId)
            {
                return await UpdateUserAsync(user);
            }
            else
            {
                return await InsertNewItemAsync(user);
            }
        }
    }
}
