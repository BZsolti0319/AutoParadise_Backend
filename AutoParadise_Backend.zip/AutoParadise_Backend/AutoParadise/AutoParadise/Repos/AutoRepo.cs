﻿using AutoParadise.Context;
using AutoParadise.Shared.Models.Entities;
using AutoParadise.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Repos
{
    public class AutoRepo : IAutoRepo
    {
        private readonly AutoParadiseInMemoryContext _dbContext;

        public AutoRepo(AutoParadiseInMemoryContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Auto?> GetBy(Guid id)
        {
            return await _dbContext.Autos.FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<Auto>> GetAll()
        {
            return await _dbContext.Autos.ToListAsync();
        }
        public async Task<ControllerResponse> UpdateAutoAsync(Auto auto)
        {
            ControllerResponse response = new ControllerResponse();
            _dbContext.ChangeTracker.Clear();
            _dbContext.Entry(auto).State = EntityState.Modified;
            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(AutoRepo)} osztály, {nameof(UpdateAutoAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{auto} frissítése nem sikerült");
            }
            return response;
        }
        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse response = new ControllerResponse();
            Auto? autoToDelete = await GetBy(id);
            if (autoToDelete == null || autoToDelete == default)
            {
                response.AppendNewError($"{id} idével rendelkező diák nem található!");
                response.AppendNewError("A diák törlése nem sikerült!");
            }
            else
            {
                _dbContext.ChangeTracker.Clear();
                _dbContext.Entry(autoToDelete).State = EntityState.Deleted;
                await _dbContext.SaveChangesAsync();
            }
            return response;

        }

        private async Task<ControllerResponse> InsertNewItemAsync(Auto auto)
        {
            ControllerResponse response = new ControllerResponse();
            try
            {
                _dbContext.Autos.Add(auto);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.AppendNewError(e.Message);
                response.AppendNewError($"{nameof(AutoRepo)} osztály, {nameof(InsertNewItemAsync)} metódusban hiba keletkezett");
                response.AppendNewError($"{auto} osztály hozzáadása az adatbázishoz nem sikerült!");
            }
            return response;
        }

        public async Task<ControllerResponse> InsertAutoAsync(Auto auto)
        {
            if (auto.HasId)
            {
                return await UpdateAutoAsync(auto);
            }
            else
            {
                return await InsertNewItemAsync(auto);
            }
        }
    }
}
