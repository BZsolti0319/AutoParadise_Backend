﻿using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Context
{
    public class AutoParadiseInMemoryContext : AutoParadiseContext
    {
        public AutoParadiseInMemoryContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Seed();
        }
    }
}
