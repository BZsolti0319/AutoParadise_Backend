﻿using AutoParadise.Shared.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Context
{
    public static class ModelBuilderExtension
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            List<Admin> admins = new List<Admin>
            {
                new Admin
                {
                    Id = Guid.NewGuid(),
                    FirstName="Kálmán",
                    LastName="Kód",
                    Address="Szeged, Fő utca 56",
                    Beosztas="Nappali",
                    MunkaID="1",
                    Email="kod.kalman@gmail.com",
                    Number="+36 3012345",
                    IsWoman=false,
                },
                new Admin
                {
                    Id = Guid.NewGuid(),
                    FirstName="Timi",
                    LastName="Tatár",
                    Address="Kiskunhalas, Köves utca 51",
                    Beosztas="Nappali",
                    MunkaID="2",
                    Email="timi.tatar@gmail.com",
                    Number="+36 3012345",
                    IsWoman=true,
                }
            };
            List<Auto> autos = new List<Auto>
            {
                new Auto
                {
                    Id = Guid.NewGuid(),
                    Marka="BMW",
                    Rendszam="AAA-111",
                    Km="116.000",
                    Allapot="Megkímélt",
                },
                new Auto
                {
                    Id = Guid.NewGuid(),
                    Marka="Honda",
                    Rendszam="BBB-222",
                    Km="260.000",
                    Allapot="Megmókolt",
                }
            };
            List<User> users = new List<User>
            {
                new User
                {
                    Id = Guid.NewGuid(),
                    FirstName="István",
                    LastName="Szegedi",
                    Address="Szeged, Fő utca 56",
                    Email="isti.szegedi@gmail.com",
                    Number="+36 3012345",
                    IsWoman=false,
                },
                new User
                {
                    Id = Guid.NewGuid(),
                    FirstName="Éva",
                    LastName="Bor",
                    Address="Kiskunhalas, Köves utca 41",
                    Email="bor.eva@gmail.com",
                    Number="+36 3012345",
                    IsWoman=true,
                }
            };

            List<CarParts> carParts = new List<CarParts>
            {
                new CarParts
                {
                    Id = Guid.NewGuid(),
                    Name = "Szélvédő",
                    Description = "Szélvédő ikszde",
                    Category = "Szélvédők",
                    Brand = "Audi"
                },
                new CarParts
                {
                    Id = Guid.NewGuid(),
                    Name = "Tesla 3000mAh",
                    Description = "Tesla 3000mAh Akkumulátor. el zakatolsz vele 10 métert",
                    Category = "Akkumulátorok",
                    Brand = "Tesla"
                },
                new CarParts
                {
                    Id = Guid.NewGuid(),
                    Name = "Pótkerék",
                    Description = "Pótkerék, szabványt ne keress nem értek hozzáxd",
                    Category = "Pótkerekek",
                    Brand = "Swag"
                }
            };

            List<CService> cServices = new List<CService>
            {
                new CService
                {
                    Id = Guid.NewGuid(),
                    FirstName="Imre",
                    LastName="Karbantartó",
                    Address="Szeged, Fő utca 56",
                    Beosztas="Nappali",
                    MunkaID="1",
                    Email="kod.kalman@gmail.com",
                    Number="+36 3012345",
                    IsWoman=false,
                },
                new CService
                {
                    Id = Guid.NewGuid(),
                    FirstName="George",
                    LastName="Mókolós",
                    Address="Kiskunhalas, Köves utca 51",
                    Beosztas="Nappali",
                    MunkaID="2",
                    Email="timi.tatar@gmail.com",
                    Number="+36 3012345",
                    IsWoman=true,
                }
            };

            modelBuilder.Entity<User>().HasData(users);
            modelBuilder.Entity<Admin>().HasData(admins);
            modelBuilder.Entity<Auto>().HasData(autos);
            modelBuilder.Entity<CarParts>().HasData(carParts);
            modelBuilder.Entity<CService>().HasData(cServices);
        }
    }
}
