﻿using AutoParadise.Shared.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace AutoParadise.Context
{
    public class AutoParadiseContext : DbContext
    {
        private DbSet<User> _users;
        private DbSet<Admin> _admins;
        private DbSet<Auto> _autos;
        private DbSet<CarParts> _carParts;
        private DbSet<CService> _cServices;

        public AutoParadiseContext(DbContextOptions<AutoParadiseContext> options)
            : base(options)
        {
        }

        public AutoParadiseContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Seed();
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Auto> Autos { get; set; }
        public DbSet<CarParts> CarParts { get; set; }
        public DbSet <CService> CService { get; set; }
    }
}
