﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AutoParadise.Shared.Extensions
{
    public static class AdminExtention
    {
        public static AdminDto ToAdminDto(this Admin admin)
        {
            return new AdminDto
            {
                Id = admin.Id,
                FirstName = admin.FirstName,
                LastName = admin.LastName,
                Address = admin.Address,
                Beosztas = admin.Beosztas,
                MunkaID = admin.MunkaID,
                Number = admin.Number,
                Email = admin.Email,
                IsWoman = admin.IsWoman,
            };
        }

        public static Admin ToAdmin(this AdminDto admindto)
        {
            return new Admin
            {
                Id = admindto.Id,
                FirstName = admindto.FirstName,
                LastName = admindto.LastName,
                Address = admindto.Address,
                Beosztas = admindto.Beosztas,
                MunkaID = admindto.MunkaID,
                Number = admindto.Number,
                Email = admindto.Email,
                IsWoman = admindto.IsWoman,
            };
        }
    }
}
