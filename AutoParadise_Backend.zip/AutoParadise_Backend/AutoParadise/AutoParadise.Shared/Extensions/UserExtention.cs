﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AutoParadise.Shared.Extensions
{
    public static class UserExtention
    {
        public static UserDto ToUserDto(this User user)
        {
            return new UserDto
            {
                Id = user.Id,
                FirstName=user.FirstName,
                LastName=user.LastName,
                Address=user.Address,
                Email=user.Email,
                Number=user.Number,
                IsWoman=user.IsWoman,
            };
        }

        public static User ToUser(this UserDto userdto)
        {
            return new User
            {
                Id = userdto.Id,
                FirstName = userdto.FirstName,
                LastName = userdto.LastName,
                Address = userdto.Address,
                Email = userdto.Email,
                Number = userdto.Number,
                IsWoman = userdto.IsWoman,
            };
        }
    }
}
