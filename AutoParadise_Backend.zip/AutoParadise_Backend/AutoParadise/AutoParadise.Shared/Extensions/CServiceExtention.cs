﻿using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Extensions
{
    public static class CServiceExtention
    {
        public static CServiceDto ToCServiceDto(this CService cService)
        {
            return new CServiceDto
            {
                Id = cService.Id,
                FirstName = cService.FirstName,
                LastName = cService.LastName,
                Address = cService.Address,
                Beosztas = cService.Beosztas,
                MunkaID = cService.MunkaID,
                Number = cService.Number,
                Email = cService.Email,
                IsWoman = cService.IsWoman,
            };
        }

        public static CService ToCService(this CServiceDto cServicedto)
        {
            return new CService
            {
                Id = cServicedto.Id,
                FirstName = cServicedto.FirstName,
                LastName = cServicedto.LastName,
                Address = cServicedto.Address,
                Beosztas = cServicedto.Beosztas,
                MunkaID = cServicedto.MunkaID,
                Number = cServicedto.Number,
                Email = cServicedto.Email,
                IsWoman = cServicedto.IsWoman,
            };
        }
    }
}
