﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;

namespace AutoParadise.Shared.Extensions
{
    public static class AutoExtention
    {
        public static AutoDto ToAutoDto(this Auto auto)
        {
            return new AutoDto
            {
                Id = auto.Id,
                Marka=auto.Marka,
                Rendszam=auto.Rendszam,
                Km=auto.Km,
                Allapot=auto.Allapot,
            };
        }

        public static Auto ToAuto(this AutoDto autodto)
        {
            return new Auto
            {
                Id = autodto.Id,
                Marka = autodto.Marka,
                Rendszam = autodto.Rendszam,
                Km = autodto.Km,
                Allapot = autodto.Allapot,
            };
        }
    }
}
