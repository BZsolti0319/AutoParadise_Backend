﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;

namespace AutoParadise.Shared.Extensions
{
    public static class CarPartsExtention
    {
        public static CarPartsDto ToCarPartsDto(this CarParts carParts)
        {
            return new CarPartsDto
            {
                Id = carParts.Id,
                Name = carParts.Name,
                Description = carParts.Description,
                Category = carParts.Category,
                Brand = carParts.Brand,
            };
        }
        public static CarParts ToCarParts(this CarPartsDto carPartsDto)
        {
            return new CarParts
            {
                Id = carPartsDto.Id,
                Name = carPartsDto.Name,
                Description = carPartsDto.Description,
                Category = carPartsDto.Category,
                Brand = carPartsDto.Brand
            };
        }
    }
}
