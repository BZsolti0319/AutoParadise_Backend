﻿namespace AutoParadise.Shared
{
    public class Class1
    {

    }
}
