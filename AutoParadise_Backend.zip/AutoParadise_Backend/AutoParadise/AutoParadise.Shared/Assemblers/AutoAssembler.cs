﻿using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Assemblers
{
    public static class AutoAssembler
    {
        public static Auto ToModel(this AutoDto autoDto)
        {
            return new Auto
            {
                Id = autoDto.Id,
                Marka = autoDto.Marka,
                Rendszam = autoDto.Rendszam,
                Km = autoDto.Km,
                Allapot = autoDto.Allapot,
            };
        }

        public static AutoDto ToDto(this Auto auto)
        {
            return new AutoDto
            {
                Id = auto.Id,
                Marka = auto.Marka,
                Rendszam = auto.Rendszam,
                Km = auto.Km,
                Allapot = auto.Allapot,
            };
        }
    }
}
