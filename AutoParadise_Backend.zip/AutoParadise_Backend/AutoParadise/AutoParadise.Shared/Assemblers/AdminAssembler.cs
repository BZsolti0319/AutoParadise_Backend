﻿using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Assemblers
{
    public static class AdminAssembler
    {
        public static Admin ToModel(this AdminDto adminDto)
        {
            return new Admin
            {
                Id = adminDto.Id,
                FirstName = adminDto.FirstName,
                LastName = adminDto.LastName,
                Address = adminDto.Address,
                Beosztas = adminDto.Beosztas,
                MunkaID = adminDto.MunkaID,
                Email = adminDto.Email,
                Number = adminDto.Number,
                IsWoman = adminDto.IsWoman,
            };
        }

        public static AdminDto ToDto(this Admin admin)
        {
            return new AdminDto
            {
                Id = admin.Id,
                FirstName = admin.FirstName,
                LastName = admin.LastName,
                Address = admin.Address,
                Beosztas = admin.Beosztas,
                MunkaID = admin.MunkaID,
                Email = admin.Email,
                Number = admin.Number,
                IsWoman = admin.IsWoman,
            };
        }
    }
}
