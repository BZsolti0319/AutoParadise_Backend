﻿using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Assemblers
{
    public static class UserAssembler
    {
        public static User ToModel(this UserDto userDto)
        {
            return new User
            {
                Id = userDto.Id,
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Address = userDto.Address, 
                Email = userDto.Email,
                Number = userDto.Number,
                IsWoman = userDto.IsWoman,
            };
        }

        public static UserDto ToDto(this User user)
        {
            return new UserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Address = user.Address,
                Email = user.Email,
                Number = user.Number,
                IsWoman = user.IsWoman,
            };
        }
    }
}
