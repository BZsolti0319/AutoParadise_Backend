﻿using AutoParadise.Shared.Dtos;
using AutoParadise.Shared.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Assemblers
{
    public static class CServiceAssembler
    {
        public static CService ToModel(this CServiceDto cServiceDto)
        {
            return new CService
            {
                Id = cServiceDto.Id,
                FirstName = cServiceDto.FirstName,
                LastName = cServiceDto.LastName,
                Address = cServiceDto.Address,
                Beosztas = cServiceDto.Beosztas,
                MunkaID = cServiceDto.MunkaID,
                Email = cServiceDto.Email,
                Number = cServiceDto.Number,
                IsWoman = cServiceDto.IsWoman,
            };
        }

        public static CServiceDto ToDto(this CService cService)
        {
            return new CServiceDto
            {
                Id = cService.Id,
                FirstName = cService.FirstName,
                LastName = cService.LastName,
                Address = cService.Address,
                Beosztas = cService.Beosztas,
                MunkaID = cService.MunkaID,
                Email = cService.Email,
                Number = cService.Number,
                IsWoman = cService.IsWoman,
            };
        }
    }
}
