﻿namespace AutoParadise.Shared.Models.Entities
{
    public class User
    {
        public User()
        {
            Id = Guid.NewGuid();
            FirstName = string.Empty;
            LastName = string.Empty;
            Address = string.Empty;
            Email = string.Empty;
            Number = string.Empty;
            IsWoman = false;
        }
        public User(string firstName, string lastName, string address, string email, string number, bool isWoomen)
        {
            Id = Guid.NewGuid();
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Email = email;
            Number = number;
            IsWoman = isWoomen;
        }
        public User(Guid id, string firstName, string lastName, string address, string email, string number, bool isWoomen)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Email = email;
            Number = number;
            IsWoman = isWoomen;
        }
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string Number { get; set; }
        public bool IsWoman { get; set; }
        public bool HasId => Id != Guid.Empty;
        public override string ToString()
        {
            return $"{LastName} {FirstName}";
        }
    }
}
