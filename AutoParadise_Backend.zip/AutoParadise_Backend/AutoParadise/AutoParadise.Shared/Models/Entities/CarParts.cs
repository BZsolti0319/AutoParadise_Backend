﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Models.Entities
{
    public class CarParts
    {
    
        public CarParts()
        {
            Id = Guid.NewGuid();
            Name = string.Empty;
            Description = string.Empty;
            Category = string.Empty;
            Brand = string.Empty;
        }

        public CarParts(string name, string description, string category, string brand)
        {
            Id = new Guid();
            Name = name;
            Description = description;
            Category = category;
            Brand = brand;
        }

        public CarParts(Guid id, string name, string description, string category, string brand)
        {
            Id = id;
            Name = name;
            Description = description;
            Category = category;
            Brand = brand;
        }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string Brand { get; set; }
        public bool HasId => Id != Guid.Empty;

        public override string ToString() 
        {
            return $"{Id} {Name}";
        }
    }
}
