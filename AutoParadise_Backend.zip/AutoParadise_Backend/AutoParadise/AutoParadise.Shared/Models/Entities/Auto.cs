﻿namespace AutoParadise.Shared.Models.Entities
{
    public class Auto
    {
        public Auto()
        {
            Id = Guid.NewGuid();
            Marka = string.Empty;
            Rendszam = string.Empty;
            Km = string.Empty;
            Allapot = string.Empty;
        }
        public Auto(string marka, string rendszam, string km, string allapot)
        {
            Id = Guid.NewGuid();
            Marka = marka;
            Rendszam = rendszam;
            Km = km;
            Allapot = allapot;
        }
        public Auto(Guid id, string marka, string rendszam, string km, string allapot)
        {
            Id = id;
            Marka = marka;
            Rendszam = rendszam;
            Km = km;
            Allapot = allapot;
        }
        public Guid Id { get; set; }
        public string Marka { get; set; }
        public string Rendszam { get; set; }
        public string Km { get; set; }
        public string Allapot { get; set; }
        public bool HasId => Id != Guid.Empty;
        public override string ToString()
        {
            return $"{Marka} {Rendszam}";
        }
    }
}
