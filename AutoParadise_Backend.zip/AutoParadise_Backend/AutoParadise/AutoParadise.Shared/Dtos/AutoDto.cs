﻿using AutoParadise.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AutoParadise.Shared.Dtos
{
    public class AutoDto
    {
        public Guid Id { get; set; }
        public string Marka { get; set; } = string.Empty;
        public string Rendszam { get; set; } = string.Empty;
        public string Km { get; set; } = string.Empty;
        public string Allapot { get; set; } = string.Empty;

        public AutoDto(Guid id, string marka, string rendszam, string km, string allapot)
        {
            Id = id;
            Marka = marka;
            Rendszam = rendszam;
            Km = km;
            Allapot = allapot;
        }

        public AutoDto()
        {
            Id = Guid.NewGuid();
            Marka = string.Empty;
            Rendszam = string.Empty;
            Km = string.Empty;
            Allapot = string.Empty;
        }
    }
}
