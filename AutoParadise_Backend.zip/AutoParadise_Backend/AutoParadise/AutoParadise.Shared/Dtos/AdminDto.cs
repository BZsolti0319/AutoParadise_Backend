﻿using AutoParadise.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoParadise.Shared.Dtos
{
    public class AdminDto
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty ;
        public string Beosztas { get; set; } = string .Empty ;  
        public string MunkaID { get; set; } = string.Empty; 
        public string Email { get; set; } = string.Empty;
        public string Number { get; set; } = string.Empty;
        public bool IsWoman { get; set; }

        public AdminDto(Guid id, string firstName, string lastName, string address, string beosztas, string munkaid, string email, string number, bool isWoomen)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Beosztas = beosztas;
            MunkaID = munkaid;
            Email = email;
            Number = number;
            IsWoman = isWoomen;
        }

        public AdminDto()
        {
            Id = Guid.NewGuid();
            FirstName = string.Empty;
            LastName = string.Empty;
            Address = string.Empty;
            Beosztas = string.Empty;
            MunkaID=string.Empty;
            Email = string.Empty;
            Number = string.Empty;
            IsWoman = false;
        }
    }
}
