﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoParadise.Shared.Models;

namespace AutoParadise.Shared.Dtos
{
    public class CarPartsDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Brand { get; set; } = string.Empty;

        public CarPartsDto(Guid id, string name, string description, string category, string brand) 
        {
            Id = id;
            Name = name;
            Description = description;
            Category = category;
            Brand = brand;
        }
        public CarPartsDto() 
        {
            Id = Guid.NewGuid();
            Name = string.Empty;
            Description = string.Empty;
            Category = string.Empty;
            Brand = string.Empty;
        }
    }
}
